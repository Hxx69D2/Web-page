﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bubblesort_example
{
    public class BubbleSort
    {
        // Overloaded function to allow sorting with an implied direction
        public int[] sort(params int[] sorting)
        {
            return sort(true, sorting);
        }
        
        /* Sorting routine, requires at boolean value for ascending or decending
         * and an array of int for the actual values to be sorted */
        public int[] sort(Boolean ascending, params int[] sorting)
        {
            Boolean swapped = false;
            int counter = sorting.Length;
            int temp;

            do
            {
                swapped = false;
                for (int i = 0; i < counter - 1; i++)
                {
                    /* check to see which direction we are sorting in.  There are
                     * more efficient (in terms of code length) ways of doing this
                     * but this is easier to read */
                    if (ascending)
                    {
                        if (sorting[i] > sorting[i + 1])
                        {
                            temp = sorting[i];
                            sorting[i] = sorting[i + 1];
                            sorting[i + 1] = temp;
                            swapped = true;
                        }
                    }
                    else
                    {
                        if (sorting[i] < sorting[i + 1])
                        {
                            temp = sorting[i];
                            sorting[i] = sorting[i + 1];
                            sorting[i + 1] = temp;
                            swapped = true;
                        }
                    }
                }
                counter--;
            } while (swapped);

            return sorting;
        }

    }

    public class Tester
    {
        public static void printArray(params int[] printing)
        {
            foreach (int i in printing)
            {
                Console.Write("{0} ", i);
            }
            Console.WriteLine("\n");
        }
        
        static void Main()
        {
            BubbleSort bubbleSort = new BubbleSort();
            Random r = new Random();

            int[] myArray = new int[15];
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = r.Next(99);
            }

            printArray(myArray);
            myArray = bubbleSort.sort(false, myArray);
            printArray(myArray);
            Console.WriteLine("\n");

            int[] newArray = new int[10];
            for (int i = 0; i < newArray.Length; i++)
            {
                newArray[i] = r.Next(200);
            }

            printArray(newArray);
            newArray = bubbleSort.sort(newArray);
            printArray(newArray);

            Console.WriteLine("Hit enter to continue");
            Console.Read();
        }
    }
}
