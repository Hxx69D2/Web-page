<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Programming Examples</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<div id="wrapper">
	<?php
	 $location = programming;
	 require("/home/users/web/b185/ipg.arnorcrosscouk/header.php");
	?>
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="program">
			<p><h3>PHP/HTML contact page example</h3></p>

			<p>This is the source for the contact page.  The contact page consists of a form to fill in which will send me an email. It also has a captcha included to slow down bots.</p>
			
			<p>The zip contains the PHP source file.</p>

			<p align="center"><font size="4"><img src="images/download_file.png" /><a href="files/Php_Contact_example.zip">Contact page example</a></font></p>

		<div style="clear: both;">&nbsp;</div>
		</div>
		<!-- end #program -->
		<?php
		 require("/home/users/web/b185/ipg.arnorcrosscouk/sidebar.php");
		?>
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<?php
	 require("/home/users/web/b185/ipg.arnorcrosscouk/footer.php");
	 ?>
</body>