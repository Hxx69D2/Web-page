<?php
$public_key = '6Lf-qNISAAAAAKU1wOsUU699bAf_oQ22cu4WlXM_';
$private_key = '6Lf-qNISAAAAAC16QuUMnw1NX3rMA3MUk2Wmway6';
?>