<div id="sidebar">
	<ul>
		<li>
			<h2>Welcome</h2>
			<p>This is my web site and an example of my skills.  Please take your time to look round.</p>
		</li>
		<li>
			<h2>About me</h2>
			<ul>
				<li><a href="about.php">Full deatils</a></li>
				<li><a href="files/Andrew_Norcross.doc">My CV</a></li>
			</ul>
		</li>
		<li>
			<h2>Program examples</h2>
			<ul>
				<li><a href="programming.php#csharp">C# programs</a></li>
				<li><a href="programming.php#java">Java programs</a></li>
				<li><a href="programming.php#html">HTML/CSS/PHP</a></li>
				<li><a href="programming.php#php">PHP/SQL</a></li>
			</ul>
		</li>
		<li>
			<h2>Contact</h2>
			<ul>
				<li><a href="contact.php">Contact me</a></li>
			</ul>
		</li>
		<li>
			<h2>Around the Internet</h2>
			<ul>
				<li><a href="internet.php">Favourite sites</li>
			</ul>
		</li>
	</ul>
</div>
<!-- end #sidebar -->
