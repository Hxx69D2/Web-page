<p><h3>Languages and Experience</h3></p>

<table border=0 cellspacing=0 cellpadding=6>
 <tr>
  <th>Language</th>
  <th>Experience</th>
  <th>Language</th>
  <th>Experience</th>
  <th>Language</th>
  <th>Experience</th>
 </tr>
 <tr>
  <td>C#</td>
  <td>4 years</td>
  <td>C++</td>
  <td>2 years</td>
  <td>Vista</td>
  <td>8 years</td>
 </tr>
 <tr>
  <td>Java</td>
  <td>4 years</td>
  <td>Pascal</td>
  <td>3 years</td>
  <td>Delphi</td>
  <td>1 year</td>
 </tr>
 <tr>
  <td>C</td>
  <td>1 year</td>
  <td>Fortran</td>
  <td>1 year</td>
  <td>Visual Basic</td>
  <td>2 years</td>
 </tr>
 <tr>
  <td>Cobol</td>
  <td>1 year</td>
  <td>MySQL</td>
  <td>4 years</td>
  <td>MS SQL Server</td>
  <td>3 years</td>
 </tr>
 <tr>
  <td>Apache</td>
  <td>4 years</td>
  <td>Winforms</td>
  <td>2 years</td>
  <td>Business Objects</td>
  <td>3 years</td>
 </tr>
 <tr>
  <td>HTML</td>
  <td>4 years</td>
  <td>PHP</td>
  <td>4 years</td>
  <td>ASP</td>
  <td>2 years</td>
 </tr>
  <tr>
   <td>CSS</td>
   <td>4 years</td>
   <td></td>
   <td></td>
   <td></td>
   <td></td>
 </tr>
</table>

<p>I used C#, HTML, CSS, PHP and MySQL with soma Apache when I was a self employed web designer.  HTML and CSS to create the web pages, PHP to make them interactive and SQL create and utilise the back end databases. C# was used to write programs to update and maintain the databases.</p>

<p>During my time with Penguin I was mainly using Vista as a developing language, but I also used MSSQL, ASP and Business Objects at various times.</p>

<p>My skills with Pascal, Cobol and Fortran were gained at University.  After leaving I moved into programming in Delphi as a logical extension of my Pascal skills.  Also in my spare time I worked on C and C++.</p>

<p><h3>Other Skills</h3></p>
<p><ul><li>Able to use Word and Excel to a high degree of proficiency</li>
<li>Can build and maintain computers</li>
<li>Can construct and maintain computer networks</li>
<li>Good interpersonal and telephone skills</li></ul></p>
