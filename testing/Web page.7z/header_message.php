<?php
	$message_number = rand(1,3);
	switch ($message_number)
	{
		case 1:
			echo "C# and Java Programmer";
			break;
		case 2:
			echo ".NET developer";
			break;
		case 3:
			echo "Web Site designer";
			break;
	}
?>