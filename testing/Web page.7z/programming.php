<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Programming Examples</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<div id="wrapper">
	<?php
	 $location = programming;
	 require("/home/users/web/b185/ipg.arnorcrosscouk/header.php");
	?>
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
		<div id="programming">
			<br /><p>Here are examples of my programming ability.  The section is seperated into sections for different languages and each code example along with comments are on a seperate page.</p>
		<div id="content">
			<div class="post">
				<p class="meta"><span class="date">C# programs</span><span class="posted">Posted by Andrew</span><a name="#csharp"></a></p>
				<div style="clear: both;">&nbsp;</div>
				<div class="entry">
					<p><a href="programsCSharpBubbleSort.php">Bubble sort class</a><p>
					<p class="indent">A simple bubble sort class in C# along with an example program.</p>
				</div>
			</div>
			<div class="post">
				<p class="meta"><span class="date">Java programs</span><span class="posted">Posted by Andrew</span><a name="#java"></a></p>
				<div style="clear: both;">&nbsp;</div>
				<div class="entry">
					<p><a href="programsJavaBubbleSort.php">Bubble sort class</a><p>
					<p class="indent">A simple bubble sort class in Java along with an example program.</p>
				</div>
			</div>
			<div class="post">
				<p class="meta"><span class="date">HTML/CSS/PHP</span><span class="posted">Posted by Andrew</span><a name="#html"></a></p>
				<div style="clear: both;">&nbsp;</div>
				<div class="entry">
					<p>This web site.</p>
					<p class="indent">HTML and CSS based with PHP all over.  The contact page has a simple form that will email me the comments when filled in correctly and complain when filled in incorrectly.</p>
					<p class="indent">The comment next to my name in the header changes.  I have tried a number of phrases in that position, none of which I was completely happy with, so in the end I decided to use them all.</p>
				</div>
			</div>
			<div class="post">
				<p class="meta"><span class="date">PHP/SQL</span><span class="posted">Posted by Andrew</span><a name="#php"></a></p>
				<div style="clear: both;">&nbsp;</div>
				<div class="entry">
					<p>Front page.</p>
					<p class="indent">The front page has a news section that is stored on a MySQL database.  PHP is used to connect to the database and display the results.</p>
				</div>
			</div>
		</div>
		<div style="clear: both;">&nbsp;</div>
		</div>
		<!-- end #programming -->
		<?php
		 require("/home/users/web/b185/ipg.arnorcrosscouk/sidebar.php");
		?>
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
	</div>
	<!-- end #page -->
</div>
	<?php
	 require("/home/users/web/b185/ipg.arnorcrosscouk/footer.php");
	 ?>
</body>