<p><h3>Overview</h3></p>
<p>I have 12 years experience and knowledge within the web design and computer programming industries. My extensive knowledge covers Blue Chip Financial and Logistic companies which has enabled me to be flexible, adaptable and reliable. I consider myself fully capable of implementing a new system or web site from initial design, to full roll out using my own initiative, experience and resources. This in turn ensures that I deliver top class results.</p>

<p>I am currently studying M255 with the Open University.</p><br />

<p><h3>Key Achievements</h3></p>

<p><ul><li>Ran website designer company for 4 years</li>
<li>Reduced outstanding helpdesk calls by 90%</li>
<li>Implemented Y2K</li></ul></p><br /><br />
