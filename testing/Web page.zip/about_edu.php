<p><h3>Overview</h3></p>

<p><ul><li>Currently studying M255 Object-orientated programming with Java, Open University</li>
<li>Degree in Computer science from Hull University 1984 -1987</li>
<li>Diploma in Mathematics from Open University 2002</li>
<li>Diploma in Business Systems from ISEB - 2000</li>
<li>NCC Certificate in Systems Analysis and Design - 1990</li></ul></p>

<p><h3>History</h3></p>

<p>1984 - 1987, Hull University, Cottingham Road, Hull</p>

<p>1982 - 1984, Ashford College, Church Road, Ashford<br/>
<ul><li>'A' levels - Maths (B), Physics (C), Further Maths (D)</li>
<li>CSE - Chemistry (I)</li></ul></p>

<p>1978 - 1982, Abbotsford School, Stanwell Road, Ashford<br/>
<ul><li>'O' levels - Maths (A), Physics (B), English (C), Biology (C), Geography (C), Geometrical Drawing(C)</li>
<li>CSE - History (2), Metalwork (4)</li></ul></p>