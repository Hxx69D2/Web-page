
/**
 * Class Bubblesort - Class to implement a standard bubble sort routine
 *
 * @author Andrew Norcross
 * @version 1.0
 */
public class Bubblesort
{
	/**
	 * Bubblesort - sorts data into accending order
	 */
	public int[] sort (int[] sorting)
	{
		Boolean swapped = true;
		int counter = sorting.length;
		int temp;

		while (swapped)
		{
			swapped = false;
			for (int i = 0; i < counter - 1; i++)
			{
				if (sorting[i] > sorting [i + 1])
				{
					temp = sorting[i];
					sorting[i] = sorting[i+1];
					sorting[i+1] = temp;
					swapped = true;
				}
			}
			counter--;
		}

		return sorting;
	}
}
