import java.util.*;

public class Tester
{
	public static void main(String[] args)
	{
		Bubblesort bubbleSort = new Bubblesort();
		Random number = new Random();

		int[] myArray = new int[15];
		for (int i = 0; i < myArray.length; i++)
		{
			myArray[i] = number.nextInt(100);
		}

		printArray(myArray);
		bubbleSort.sort(myArray);
		printArray(myArray);
	}

	private static void printArray(int[] array)
	{
		for (int number : array)
		{
			System.out.format("%d ", number);
		}
		System.out.format("%n");
	}
}